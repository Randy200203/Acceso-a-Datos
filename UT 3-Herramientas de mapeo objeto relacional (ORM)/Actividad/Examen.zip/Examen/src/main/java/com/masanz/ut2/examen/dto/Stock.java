package com.masanz.ut2.examen.dto;

public class Stock {

    private int id;
    private int idEmpresa;
    private int idProducto;
    private int cantidad;

    public Stock() {

    }

    public Stock(int id, int idEmpresa, int idProducto, int cantidad) {
        this.id = id;
        this.idEmpresa = idEmpresa;
        this.idProducto = idProducto;
        this.cantidad = cantidad;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIdEmpresa() {
        return idEmpresa;
    }

    public void setIdEmpresa(int idEmpresa) {
        this.idEmpresa = idEmpresa;
    }

    public int getIdProducto() {
        return idProducto;
    }

    public void setIdProducto(int idProducto) {
        this.idProducto = idProducto;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    @Override
    public String toString() {
        return "Stock{" +
                "id=" + id +
                ", idEmpresa=" + idEmpresa +
                ", idProducto=" + idProducto +
                ", cantidad=" + cantidad +
                '}';
    }
}
