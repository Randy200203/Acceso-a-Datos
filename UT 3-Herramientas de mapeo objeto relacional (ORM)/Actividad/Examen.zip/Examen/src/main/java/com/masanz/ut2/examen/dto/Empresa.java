package com.masanz.ut2.examen.dto;

public class Empresa {

    private int id;
    private String nombre;
    private String sector;
    private int capital;
    private int numEmpleados;

    public Empresa() {
        id = -1;
        nombre = "";
        sector = "";
        capital = 0;
        numEmpleados = 0;
    }

    public Empresa(int id, String nombre, String sector, int capital, int numEmpleados) {
        this.id = id;
        this.nombre = nombre;
        this.sector = sector;
        this.capital = capital;
        this.numEmpleados = numEmpleados;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getSector() {
        return sector;
    }

    public void setSector(String sector) {
        this.sector = sector;
    }

    public int getCapital() {
        return capital;
    }

    public void setCapital(int capital) {
        this.capital = capital;
    }

    public int getNumEmpleados() {
        return numEmpleados;
    }

    public void setNumEmpleados(int numEmpleados) {
        this.numEmpleados = numEmpleados;
    }

    @Override
    public String toString() {
        return "Empresa{" +
                "id=" + id +
                ", nombre='" + nombre + '\'' +
                ", sector='" + sector + '\'' +
                ", capital=" + capital +
                ", numEmpleados=" + numEmpleados +
                '}';
    }
}
